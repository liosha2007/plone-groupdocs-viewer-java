"""Common configuration constants
"""

PROJECTNAME = 'groupdocs.viewer_java'

ADD_PERMISSIONS = {
    # -*- extra stuff goes here -*-
}
